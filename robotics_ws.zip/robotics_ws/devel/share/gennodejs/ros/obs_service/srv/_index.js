
"use strict";

let service_example = require('./service_example.js')

module.exports = {
  service_example: service_example,
};
